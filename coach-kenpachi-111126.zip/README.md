# Landing Page — Coach Kenpachi

Landing page de conversão para Coach Kenpachi (Consultoria Completa de
nutrição + treinamento), construída em **Next.js + React + TypeScript +
Tailwind CSS, com Static Export**. O resultado do build é HTML/CSS/JS
puro — não depende de Node.js, banco de dados ou backend em produção.

> **V2**: esta versão implementa o briefing de evolução da página (nova
> seção "Mais do que seguir um protocolo" em três blocos, planos de preço
> mensal/trimestral/semestral dentro da Consultoria Completa, Case Marcelo
> com espaço para antes/depois, FAQ com as 7 perguntas oficiais, e o
> número de WhatsApp real). A identidade visual, os componentes e a
> arquitetura da V1 foram preservados — apenas o conteúdo e as seções
> pedidas no briefing V2 foram alterados.
>
> **Migração para Tailwind CSS**: o CSS customizado (~1280 linhas de
> classes BEM como `.hero__inner`, `.btn-whatsapp--primary`) foi
> substituído por Tailwind CSS v4. O resultado visual é idêntico — só a
> forma de escrever o CSS mudou. Ver seção 7.1 para detalhes de como isso
> foi organizado.

## 1. Estrutura do projeto

```text
kenpachi/
├── docs/
│   ├── EVENTOS.md              # Padrão de rastreamento via dataLayer (GA4/GTM)
│   ├── GTM-GA4-PASSO-A-PASSO.md # Configuração do GTM e do GA4
│   └── CONSENTIMENTO.md        # Barra de cookies, consentimento e Política de Privacidade
├── public/
│   └── images/
│       └── logo-coach-kenpachi.png
├── src/
│   ├── app/
│   │   ├── layout.tsx           # Metadata, JSON-LD, <ClickTracker />, <ConsentManager />, skip-link
│   │   ├── politica-de-privacidade/
│   │   │   └── page.tsx         # Página /politica-de-privacidade/ (LGPD)
│   │   ├── page.tsx             # Composição das seções da landing page
│   │   ├── globals.css          # @import "tailwindcss" + tokens de marca (@theme) + base layer
│   │   ├── sitemap.ts           # Gera sitemap.xml estático no build
│   │   └── robots.ts            # Gera robots.txt estático no build
│   ├── components/              # Um componente por seção da página (classes Tailwind direto no JSX)
│   ├── config/
│   │   ├── site.ts              # WhatsApp, mensagens, links — config central
│   │   ├── privacy.ts           # Dados e [PREENCHER] da Política de Privacidade
│   │   └── faq.ts               # As 7 perguntas/respostas do FAQ (fácil de editar)
│   └── lib/
│       ├── consent.ts           # Escolhas de cookies (localStorage, versão, data)
│       ├── analytics.ts         # pushToDataLayer (só com consentimento) + faq_interaction / scroll_depth
│       └── click-tracking.ts    # Listener delegado: whatsapp_click, navigation_click, social_click
├── next.config.mjs               # output: 'export', images.unoptimized
├── postcss.config.mjs            # Plugin do Tailwind v4
├── package.json
└── tsconfig.json
```

## 2. Instalar dependências

Requer **Node.js 20.9 ou superior** apenas em desenvolvimento/build (não em
produção — Node 18 chegou ao fim do suporte e não é mais compatível com o
Next.js 16).

```bash
npm install
```

Se você atualizou este projeto a partir de uma instalação anterior, apague
`node_modules` e `package-lock.json` antes de reinstalar, para não herdar
versões antigas e transitivas (é a causa mais comum dos avisos de
`deprecated` do npm):

```bash
rm -rf node_modules package-lock.json
npm install
```

## 3. Rodar localmente

```bash
npm run dev
```

Acesse `http://localhost:3000`.

## 4. Configurar variáveis de ambiente (opcional)

Copie `.env.example` para `.env.local`. O ID do GTM deste site é
`GTM-KK7FKGT5` (variável `NEXT_PUBLIC_GTM_ID`):

```bash
cp .env.example .env.local
```

Antes de publicar, ajuste também os placeholders em
`src/config/site.ts` (número de WhatsApp, Instagram, domínio final).

## 5. Build de produção (Static Export)

```bash
npm run build
```

O build gera a pasta estática em:

```text
out/
```

Esse é o conteúdo que deve ser publicado — apenas HTML, CSS, JS e imagens.

## 6. Publicar em servidor tradicional

1. Rode `npm run build`.
2. Copie **todo o conteúdo da pasta `out/`** (não a pasta em si) para a
   raiz pública do servidor (ex.: `public_html/`, `www/`, ou a raiz do
   domínio no seu provedor de hospedagem).
3. Nenhuma configuração de servidor Node é necessária — qualquer servidor
   de arquivos estáticos (Apache, Nginx, hospedagem compartilhada, CDN)
   funciona.

### Critério de aceitação

> Se eu pegar somente os arquivos gerados pelo build estático (`out/`) e
> enviar para um servidor tradicional, a página funcionará?

**Sim.** O projeto não usa Server Actions, API Routes, middleware
dependente de servidor, banco de dados ou autenticação server-side.

### Publicar no Netlify

O arquivo `netlify.toml` na raiz do projeto já configura isso
automaticamente:

```toml
[build]
  command = "npm run build"
  publish = "out"
```

Se o site foi criado pela interface do Netlify **antes** desse arquivo
existir, o painel pode ter salvo `dist` como "Publish directory" (padrão
genérico do Netlify, não do Next.js) — isso causa o erro
`Deploy directory 'dist' does not exist"` mesmo com o build passando. Para
corrigir: **Site settings → Build & deploy → Build settings → Edit
settings** e mude "Publish directory" para `out`, ou simplesmente
confirme que o site está lendo o `netlify.toml` do repositório (ele tem
prioridade sobre a configuração manual do painel).

## 7. Dependências utilizadas e justificativa

| Pacote | Versão | Motivo |
| --- | --- | --- |
| `next` | `^16.3.3` | Framework exigido pelo briefing, com suporte nativo a Static Export. Versão em **Active LTS**, recebendo patches de segurança mensais. |
| `react` / `react-dom` | `^19.2.0` | Exigidos pelo Next.js 16 (que requer React 19+). |
| `typescript` | `^6.0.3` | Tipagem estática, exigida pelo briefing. Versão estável (a 7.0, com compilador nativo, ainda tem API limitada para algumas ferramentas — 6.x é a escolha mais estável hoje). |
| `@types/node`, `@types/react`, `@types/react-dom` | mais recentes | Tipos compatíveis com Node 20+/22 e React 19. |
| `eslint` | `^9.20.0` | Qualidade de código em desenvolvimento (não entra no bundle final). ESLint 8 está fora de manutenção. |
| `eslint-config-next` | `^16.3.3` | Config oficial do Next.js, já no formato *flat config* (`eslint.config.mjs`) — o comando `next lint` foi removido a partir da v16. |
| `tailwindcss` | `^4.3.3` | Motor de CSS utilitário — ver seção 7.1 abaixo. |
| `@tailwindcss/postcss` | `^4.3.3` | Plugin PostCSS do Tailwind v4 (`postcss.config.mjs`). |

Nenhuma biblioteca de UI, animação, ou formulário foi adicionada — todas as
interações (menu, scroll spy, FAQ, reveal ao rolar) foram implementadas
com React e APIs nativas do navegador (`IntersectionObserver`, elemento
`<details>`), conforme a seção 26 do briefing (evitar dependências
desnecessárias).

### 7.1 Como o Tailwind foi organizado

O projeto usa a configuração "CSS-first" do Tailwind v4 (sem
`tailwind.config.js` — tudo fica em `src/app/globals.css`):

- **`@theme`**: define os tokens de marca (cores, fontes, breakpoints
  extras) como variáveis CSS. Cada token vira automaticamente uma ou mais
  classes utilitárias. As cores de marca usam o prefixo `brand-` (ex.:
  `bg-brand-orange`, `text-brand-graphite`) de propósito, para nunca serem
  confundidas com as paletas padrão do Tailwind (`orange-500` é uma cor
  totalmente diferente do nosso laranja de marca, `#fa4c16`).
- **Breakpoints extras**: além do `sm`(640px)/`md`(768px) padrão do
  Tailwind, o layout original usa alguns pontos de quebra específicos,
  registrados em `@theme` e disponíveis como variantes normais:
  `about:`(800px), `case:`(860px), `header:`(900px), `goals:`(960px).
- **`@layer base`**: só o que dependeria da mesma classe repetida em toda
  seção — tipografia de `h1`/`h2`/`h3`/`p`, cor/fonte do `body`, e a
  transição em fade de todo link/botão (pedido explícito do cliente, uma
  regra global em vez de `transition-colors` repetido em cada `<a>`).
- **Tudo o resto** (cada seção, card, botão, grid) é classe utilitária do
  Tailwind direto no `className` de cada componente — não existe mais
  nenhuma classe BEM customizada (`.hero__inner`, `.btn-whatsapp--primary`
  etc.) no projeto.
- **`sr-only`**: usa a classe nativa do Tailwind (idêntica à que o projeto
  tinha customizado antes) — nenhuma mudança necessária nesses usos.

### Sobre os avisos de `npm warn deprecated`

Os avisos de pacotes descontinuados (`inflight`, `glob@7`, `rimraf@3`,
`@humanwhocodes/*`, etc.) e o aviso de vulnerabilidade de segurança do
`next@14.2.16` vinham das versões antigas fixadas neste projeto:

- **`next@14.2.16`**: Next.js 14 chegou ao fim do suporte em 26/10/2025 e
  não recebe mais correções de segurança. Corrigido atualizando para
  `next@^16.3.3` (Active LTS).
- **`eslint@8.57.0`**: ESLint 8 está fora de manutenção; suas dependências
  internas (`glob@7`, `rimraf@3`, `inflight`) são as que geravam os avisos
  de *memory leak*/depreciação. Corrigido atualizando para `eslint@^9.20.0`
  com o novo formato *flat config* (`eslint.config.mjs`).

Depois de instalar com as versões atuais, `npm install` não deve mais
exibir esses avisos. Novos avisos de depreciação podem surgir com o tempo
— rode `npm outdated` periodicamente para revisar.

## 8. Checklist de SEO técnico

- [x] Um único `<h1>` (no Hero).
- [x] Hierarquia de `<h2>`/`<h3>` refletindo a estrutura real do conteúdo.
- [x] `title` e `meta description` centralizados em `src/config/site.ts`.
- [x] `canonical` configurado via `alternates.canonical`.
- [x] Open Graph e Twitter Card configurados.
- [x] `sitemap.xml` e `robots.txt` gerados automaticamente no build.
- [x] `alt text` em todas as imagens (logo).
- [x] Schema.org (`ProfessionalService`) com apenas dados reais e sustentados pelo briefing.
- [ ] `[VALIDAR COM O CLIENTE]`: domínio final em `siteConfig.siteUrl` antes de publicar.

## 9. Checklist de acessibilidade

- [x] HTML semântico (`header`, `nav`, `main`, `section`, `footer`).
- [x] Skip link para o conteúdo principal.
- [x] Foco visível (`:focus-visible`) em toda a página.
- [x] Contraste alto entre texto e fundo (branco/laranja sobre grafite).
- [x] FAQ implementado com `<details>`/`<summary>` nativos (sem ARIA customizado).
- [x] Áreas de toque de no mínimo 44–48px nos CTAs e botão flutuante.
- [x] `prefers-reduced-motion` respeitado (reveal e scroll suave desativados).
- [x] Nenhuma `div` clicável substituindo botão/link — todos os CTAs são `<a>` ou `<button>` semânticos.

## 10. Checklist de performance

- [x] Sem bibliotecas de UI externas. Corpo de texto usa fontes do sistema; os títulos H2 usam a fonte **Anton** (Google Fonts), carregada via `next/font/google` — o arquivo é baixado e self-hospedado **no momento do build** (requer internet só durante `npm run build`/`npm run dev`; o site publicado não faz nenhuma chamada à rede para isso).
- [x] Static Export — sem SSR, sem custo de servidor por requisição.
- [x] Apenas os componentes com interação real usam `"use client"` (nav, FAQ, reveal, botões de WhatsApp).
- [x] Imagem do logo usa `next/image` com carregamento prioritário apenas no Header.
- [x] Sem animações contínuas, parallax ou efeitos 3D.
- [x] Tailwind gera só o CSS das classes realmente usadas no projeto (detecção automática de conteúdo, sem necessidade de configurar `content: []`) — o CSS final publicado fica pequeno e sem regras não utilizadas.

## 11. Pontos que precisam ser validados com o cliente (V2)

O número de WhatsApp já é o real (`5511949080965`, briefing V2). O que
ainda falta, marcado no código como `[IMAGEM NECESSÁRIA]`,
`[IMAGEM REAL DO COACH — INSERIR]`, `[DEPOIMENTO REAL — INSERIR]`,
`[IMAGEM ANTES/DEPOIS — INSERIR COM AUTORIZAÇÃO]`,
`[RESPOSTA DO COACH — INSERIR]` ou `[LINK DO INSTAGRAM — INSERIR]`:

- **Imagem conceitual do Hero** (`src/components/Hero.tsx`) — nutrição/treino/performance, nunca foto do Coach.
- **Foto real do Coach Kenpachi** (seção Sobre — `src/components/About.tsx`).
- **Fotos antes/depois do Case Marcelo**, já autorizado (`src/components/Results.tsx`).
- **Depoimentos e fotos de outros clientes**, somente com autorização (`src/components/Results.tsx`).
- **As 7 respostas do FAQ**, a serem escritas pelo Coach (`src/config/faq.ts`).
- **Link do Instagram** (`src/config/site.ts` → `instagramUrl`; enquanto vazio, o rodapé mostra o placeholder em vez de link quebrado).
- **Imagem de fundo do CTA final** (`src/components/FinalCta.tsx`).
- **Domínio final de publicação** (`src/config/site.ts` → `siteUrl`).
- **ID do container do Google Tag Manager** (`.env.local`).

Não há mais placeholders de preço, plano, texto de seção ou copy — todo o
conteúdo textual do briefing V2 já está implementado literalmente (ver
seção 33 do briefing, "critérios de aceitação").

## 12. Como adicionar a foto real do Coach (seção Sobre)

Hoje a seção Sobre mostra um placeholder tracejado com o texto
`[IMAGEM NECESSÁRIA]`. Quando a foto estiver disponível:

1. Coloque o arquivo em `public/images/coach-kenpachi.jpg` (ou `.png`/`.webp`).
2. Em `src/components/About.tsx`, troque o bloco `<div className="about__photo-placeholder">...</div>` por:

   ```tsx
   <Image
     src="/images/coach-kenpachi.jpg"
     alt="Coach Kenpachi"
     width={480}
     height={600}
     className="about__photo"
   />
   ```

   (não esqueça de importar `Image` de `"next/image"` no topo do arquivo).
3. Opcionalmente, ajuste `.about__photo-placeholder` em `globals.css` para
   `.about__photo` (borda sólida em vez de tracejada, `object-fit: cover`).

## 13. Como trocar a imagem de fundo do CTA final

A seção final (antes do rodapé) usa uma imagem de fundo com overlay escuro
para garantir contraste do texto. Hoje ela aponta para um placeholder
gerado em [placehold.co](https://placehold.co), só para servir de guia de
enquadramento — **precisa ser substituída antes de publicar**.

1. Escolha uma imagem real (ambiente de treino, academia, ou o próprio
   coach em ação) e coloque o arquivo em `public/images/`, por exemplo
   `public/images/cta-background.jpg`.
2. Em `src/components/FinalCta.tsx`, troque a constante:

   ```tsx
   const BACKGROUND_IMAGE_URL = "/images/cta-background.jpg";
   ```

3. O overlay escuro (`.final-cta__overlay` em `globals.css`) já está
   ajustado para dar bom contraste ao texto branco sobre praticamente
   qualquer foto; ajuste a opacidade do gradiente ali caso a imagem
   escolhida seja muito clara ou muito "poluída" visualmente.

## 14. Como trocar a imagem de fundo do Hero

O Hero (topo da página) segue o mesmo padrão do CTA final: imagem de fundo
+ overlay escuro para manter o texto e o botão laranja com bom contraste.
Hoje aponta para um placeholder do placehold.co.

1. Coloque a imagem real em `public/images/`, por exemplo
   `public/images/hero-background.jpg`.
2. Em `src/components/Hero.tsx`, troque a constante:

   ```tsx
   const BACKGROUND_IMAGE_URL = "/images/hero-background.jpg";
   ```

3. O overlay (`.hero__overlay` em `globals.css`) usa o mesmo gradiente do
   CTA final; ajuste a opacidade ali se a foto escolhida for muito clara.

## 15. Troubleshooting

### `error TS5102: Option 'baseUrl' is deprecated...`

A partir do TypeScript 6.0 (instalado na atualização de dependências deste
projeto), a opção `baseUrl` do `tsconfig.json` foi descontinuada e o
compilador trata isso como erro fatal de build, não apenas aviso.

**Já corrigido neste projeto**: removemos `baseUrl` do `tsconfig.json`. Com
`"moduleResolution": "bundler"`, os `paths` (`@/*`) são resolvidos
diretamente em relação à pasta onde está o `tsconfig.json`, então não é
necessário declarar `baseUrl` — o alias `@/...` continua funcionando
normalmente em todo o projeto.

Se esse erro aparecer de novo no futuro (por exemplo, após adicionar outro
`tsconfig.json` em uma subpasta), remova `baseUrl` de lá também e confirme
que os caminhos em `paths` começam com `./`.

### `Error: Failed to collect page data for /robots.txt`

Rotas de metadata geradas por código (`robots.ts`, `sitemap.ts`) precisam
declarar explicitamente que são estáticas quando o projeto usa
`"output": "export"` — sem isso, o Next.js falha o build com esse erro
genérico (a mensagem real, `force-static`/`revalidate` não configurado,
costuma ficar escondida atrás desse wrapper).

**Já corrigido neste projeto**: adicionamos `export const dynamic = "force-static";`
no topo de `src/app/robots.ts` e `src/app/sitemap.ts`. Se você criar novas
rotas de metadata (`opengraph-image.tsx`, `icon.tsx`, etc.), adicione a
mesma linha nelas também.

## 16. Rastreamento de cliques (dataLayer / GTM / GA4)

O site segue o padrão de rastreamento via dataLayer usado nos sites dos
parceiros (padrão D.R.A. Seguros). Documentação completa, com a tabela de
todos os elementos rastreados, em [`docs/EVENTOS.md`](docs/EVENTOS.md).

Resumo:

- Eventos: `whatsapp_click`, `navigation_click`, `social_click`, sempre com
  exatamente cinco parâmetros: `page_name`, `section_name`, `button_name`,
  `button_label`, `link_url`.
- Um único listener de clique por delegação (`src/lib/click-tracking.ts`),
  montado uma vez no layout por `<ClickTracker />`. Componentes não têm
  `onClick` de tracking.
- Para rastrear um novo link basta adicionar atributos:
  - WhatsApp: `data-wa-section` e `data-wa-button` (ou as props `section` e
    `button` do `WhatsAppCta`).
  - Outra página / rede social: `data-track-event` (`navigation_click` ou
    `social_click`), `data-track-section` e `data-track-button`.
- Âncoras da mesma página, `mailto:` e `tel:` não geram evento.
- GTM: `NEXT_PUBLIC_GTM_ID=GTM-KK7FKGT5`. A variável é gravada no build:
  defina-a no Netlify (Site configuration → Environment variables) e faça um
  novo deploy depois de qualquer alteração.
- O GTM e o `dataLayer` só funcionam **após aceitar cookies analíticos** (seção 17).
- Teste: abra o site, clique em **Aceitar todos** na barra de cookies, rode
  `window.dataLayer` no console e clique nos botões; depois valide no Preview
  do GTM e no DebugView do GA4.

## 17. Cookies, consentimento e Política de Privacidade

O site tem barra de cookies, central de personalização e a página
`/politica-de-privacidade/` (LGPD). Documentação completa em
[`docs/CONSENTIMENTO.md`](docs/CONSENTIMENTO.md).

- **GTM e `dataLayer` só com consentimento analítico.** Sem aceite, o GTM não é
  carregado e nenhum evento é enviado. Recusar ou revogar interrompe a coleta
  (o site limpa os cookies do Google e recarrega a página).
- Categorias: necessários (sempre ativos), analíticos e marketing (desativados
  por padrão). Aceitar e Recusar têm o mesmo destaque.
- A escolha fica no `localStorage` (data e versão). Para pedir nova escolha a
  todos, aumente `CONSENT_VERSION` em `src/lib/consent.ts`.
- Rodapé: "Política de Privacidade" e "Preferências de cookies".
- **Pendente:** campos `[PREENCHER]` da Política (nome/razão social, CPF/CNPJ,
  retenção do GA4, medidas de segurança). Ver `src/config/privacy.ts`.
- O bloco `<noscript>` do GTM foi removido de propósito.
